///===================================
///                                   INCLUDES
///===================================
///System
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <unordered_map>

///JSON
#include "JsonNlohmann/json.hpp"

///AngelScript
#include "AngelScript/angelscript.h"

///AngelScript Addons
#include "AngelScript/scriptarray.h"
#include "AngelScript/scriptbuilder.h"
#include "AngelScript/scriptdictionary.h"
#include "AngelScript/scriptmath.h"
#include "AngelScript/scriptstdstring.h"

///GL
#include "GLAD/glad.h"
#include "SDL3/SDL.h"
#include "GLM/glm.hpp"

///EnTT
#include "EnTT/entt.hpp"

///TinyglTF
#include "TinyglTF/tiny_gltf_v3.h"

///ARTENGINE
#include "engineWindow.h"
#include "engineShader.h"
#include "engineAngelScriptCallback.h"

#include "engineDefinitionsAssets.h"
#include "engineDefinitionsComponents.h"
#include "engineComponents.h"
#include "engineRegisterComponents.h"
#include "engineDefineComponentsEvents.h"

#include "engineEntityLoader.h"
#include "engineSceneLoader.h"
#include "engineAssetManager.h"
#include "engineShaderLoad.h"

#include "engineUpdateComponents.h"

#include "utilsJson.h"
#include "utilsString.h"
#include "utilsUDP.hpp"
#include "utilsUUID.h"

#include "apiRegisterEngineAPIBasics.h"
#include "apiRegisterEngineAPIEnums.h"
#include "apiRegisterEngineAPIInput.h"
#include "apiRegisterEngineAPITransform.h"
#include "apiRegisterEngineAPIAnimation.h"
#include "apiRegisterengineAPIObjects.h"


///ARTENGINE DEBUG
#include "debugEntities.h"
///===================================
///                        INITIALIZE VARIABLES
///===================================

///Manifests
nlohmann::json AssetsManifests;
nlohmann::json EntityManifests;
nlohmann::json GameManifests;
nlohmann::json SceneManifests;
nlohmann::json ShaderManifests;

///Assets
std::unordered_map<std::string, AssetScript> AssetMapScript;
std::unordered_map<std::string, AssetModel> AssetMapModel;
std::unordered_map<std::string, Shader> AssetMapShader;

///Components
std::vector<Components> EntityComponentsRegis;
std::unordered_map<std::string, size_t>EntityComponentsRegisIndexes;

///Entity ECS
entt::registry EntityRegistry;

///AngelScript Engine
asIScriptEngine* ASengine;

///Initialize window class
Window window;

///Actual update entity
entt::entity script_update_actual_entity;

///GL Version
const char* shaderVersion = "";

///Initialize logger
udp::Socket loggerSock;
std::string loggerUUID = "";

int main(){
    std::cout << "[ARTENGINE] Starting ARTEngine" << std::endl;

    ///Start LOGGER socket
    loggerSock.set_nonblocking(true);

    loggerUUID = GenerateUUID();

    ///AngelScript Start Engine
    std::cout << "[AngelScript] Starting AngelScript Engine" << std::endl;
    ASengine = asCreateScriptEngine();
    if(ASengine == nullptr){
        std::cout << "[AngelScript] Something went wrong trying to initialize AngelScript Engine... :C" << std::endl;
        return 0;
    }

    ///AngelScript Set Message Callback
    ASengine->SetMessageCallback(asFUNCTION(MessageCallback),0,asCALL_CDECL);

    ///AngelScript Define Functions
    RegisterStdString(ASengine);
    RegisterScriptArray(ASengine,true);
    RegisterScriptDictionary(ASengine);
    RegisterScriptMath(ASengine);

    ///AngelScript Define API Functions
    RegisterEngineAPIEnums(ASengine);
    RegisterEngineAPIObjects(ASengine);

    RegisterEngineAPIBasics(ASengine);
    RegisterEngineAPIInput(ASengine);
    RegisterEngineAPITransform(ASengine);
    RegisterEngineAPIAnimation(ASengine);

    ///EnTT Set Definitions
    DefineEntityComponents();

    ///EnTT Define Components Events
    DefineComponentsEvents();

    ///Load Game Manifest
    if(!utilLoadJson("gamefiles/game_manifest.json",GameManifests)){
        return 0;
    }
    ///Load Assets Manifest
    if(!utilLoadJson("gamefiles/assets_manifest.json",AssetsManifests)){
        return 0;
    }
    ///Load Entities Manifest
    if(!utilLoadJson("gamefiles/entity_manifest.json",EntityManifests)){
        return 0;
    }
    ///Load Scenes Manifest
    if(!utilLoadJson("gamefiles/scene_manifest.json",SceneManifests)){
        return 0;
    }
    ///Load Shaders Manifest
    if(!utilLoadJson("gamefiles/shader_manifest.json",ShaderManifests)){
        return 0;
    }

    window.Initialize(GameManifests["window_width"],GameManifests["window_height"],GameManifests["name"]);

    if(!window.IsWindowValid()){
        std::cout << "[ARTENGINE] Closing ARTENGINE due to an error on initializing Window.. :C" << std::endl;
        return 0;
    }

    ///Get Shader Version
    shaderVersion = (const char*)glGetString(GL_SHADING_LANGUAGE_VERSION);

    ///Load All Shaders
    ShaderLoad();

    glEnableVertexAttribArray(0);
    glEnable(GL_DEPTH_TEST);

    LoadScene(GameManifests["starting_scene"]);
    ///Set the last time for Deltatime
    Uint64 DTLastTime = SDL_GetTicks();


    while(!window.ShouldClose()){
        ///Update DeltaTime
        Uint64 DTCurrentTime = SDL_GetTicks();
        float DeltaTime = (DTCurrentTime - DTLastTime) / 1000.0f;
        DTLastTime = DTCurrentTime;

        if (window.IsKeyJustPressed(SDL_SCANCODE_F1)){
            LoadScene("sceneTest");
        }
        if (window.IsKeyJustPressed(SDL_SCANCODE_F2)){
            DebugPrintAllEntities();
        }

        UpdateScripts(DeltaTime);
        UpdateAnimations(DeltaTime);

        glClearColor(0.0f,0.2235f,0.4275f,1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        UpdateDrawMeshes(1);

        window.SwapBuffers();
        window.PollEvents();
    }
    return 0;
}
