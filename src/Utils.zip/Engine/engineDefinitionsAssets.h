#pragma once

#include <string>
#include <vector>

#include "GLM/glm.hpp"
#include "GLM/gtc/quaternion.hpp"


#include "AngelScript/angelscript.h"


#include "engineShader.h"

    /* ASSETS TYPE THAT CAN APPEAR IN ASSETS PART IN SCENE JSON
        Type 0 : Script
        Type 1 : Sprite
        Type 3 : Model
        Type 4 : Font
        Type 5 : Sound
        Type 6 : Shader
    */

struct AssetScript{
    std::string path;
    std::string className;

    asIScriptModule* scriptModule = nullptr;
    asITypeInfo* classType = nullptr;
    asIScriptFunction* factory = nullptr;

    asIScriptFunction* onCreate = nullptr;
    asIScriptFunction* onUpdate = nullptr;
    asIScriptFunction* onDestroy = nullptr;
};

struct AssetModelPart{
    unsigned int VAO = 0, VBO = 0, EBO = 0;

    int indexCount = 0;
    unsigned int texture = 0;
    float color[4] = {1,1,1,1};

    bool skinned = false;               // true = los vertices llevan huesos y pesos y se dibuja con bones[]
};

// ---- Esqueleto y animaciones (datos del MODELO, compartidos por todas las entidades) ----
struct AssetBone{
    std::string name;
    int parent = -1;                       // indice de hueso del padre, -1 = raiz
    glm::vec3 translation{0.0f};           // pose de reposo (local)
    glm::quat rotation{1.0f, 0.0f, 0.0f, 0.0f};
    glm::vec3 scale{1.0f};
    glm::mat4 inverseBind{1.0f};
};

struct AssetSkeleton{
    std::vector<AssetBone> bones;          // mismo orden que skin.joints (= JOINTS_0 de los vertices)
    std::vector<int> order;                // indices de huesos con el padre siempre antes que el hijo
    glm::mat4 rootMatrix{1.0f};            // transformacion de lo que esta arriba de los huesos raiz
};

struct AnimChannel{
    int bone = -1;
    int path = 0;                          // 0 = traslacion, 1 = rotacion, 2 = escala
    int interp = 0;                        // 0 = LINEAR, 1 = STEP
    std::vector<float> times;              // segundos
    std::vector<float> values;             // vec3 (traslacion/escala) o quat x,y,z,w (rotacion), 1 por tiempo
};

struct AssetAnimation{
    std::string name;
    float duration = 0.0f;
    std::vector<AnimChannel> channels;
};

struct AssetModel{
    std::string path;
    std::vector<AssetModelPart> parts;
    std::vector<unsigned int> textures;

    bool hasSkeleton = false;
    AssetSkeleton skeleton;
    std::vector<AssetAnimation> animations;
};
